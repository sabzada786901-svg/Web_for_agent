@echo off
title AgenticAim - AI Esports Aim Coach & Hardware Advisor
echo ========================================================
echo   AgenticAim - AI Esports Aim Coach & Hardware Advisor
echo   AMD Developer Hackathon III Project
echo ========================================================
echo.
echo Checking Python environment...
python --version
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH. Please install Python 3.10+.
    pause
    exit /b 1
)

if not exist ".env" (
    if exist ".env.example" (
        echo [INFO] Creating .env from .env.example...
        copy .env.example .env
    )
)

echo.
echo Installing / verifying required packages...
pip install -r requirements.txt

echo.
echo Starting AgenticAim Server...
echo Open http://localhost:8000 in your browser.
python main.py
pause
